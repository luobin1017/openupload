<?php
/**
 *
 * @copyright        2017 www.guangdawangluo.com - All Rights Reserved
 * @author           opencart.cn <support@opencart.cn>
 * @created          2016-10-22 09:12:56
 * @modified         2016-11-05 17:35:21
 */

// Heading
$_['heading_title']                = '控制面板';

$_['footer_btn_close']                = '朕不想看';
$_['footer_btn_link']                = '前往围观';

// Error
$_['error_install']                = '警告：安装文件夹仍然存在，出于安全原因，请立即删除！';
